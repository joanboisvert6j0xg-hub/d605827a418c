// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("submodule sync\n", stdout);
  return lionss_run_workload("submodule-sync");
}
