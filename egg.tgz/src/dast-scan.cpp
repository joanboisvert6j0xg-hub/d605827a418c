// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("dast scan"); }
int main(){
  announce();
  return lionss_run_workload("dast-scan");
}
