# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(linux-mips64 src/linux-mips64.cpp)
set_property(TARGET linux-mips64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-mips64 lionss pthread)

add_executable(serialization-tests src/serialization-tests.cpp)
set_property(TARGET serialization-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(serialization-tests lionss pthread)

add_executable(meson-build src/meson-build.cpp)
set_property(TARGET meson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(meson-build lionss pthread)

add_executable(submodule-sync src/submodule-sync.cpp)
set_property(TARGET submodule-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(submodule-sync lionss pthread)

add_executable(negative-tests src/negative-tests.cpp)
set_property(TARGET negative-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(negative-tests lionss pthread)

add_executable(property-tests src/property-tests.cpp)
set_property(TARGET property-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(property-tests lionss pthread)

add_executable(decoder-fuzz src/decoder-fuzz.cpp)
set_property(TARGET decoder-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(decoder-fuzz lionss pthread)

add_executable(api-reference src/api-reference.cpp)
set_property(TARGET api-reference PROPERTY CXX_STANDARD 11)
target_link_libraries(api-reference lionss pthread)

add_executable(tidy-bugprone src/tidy-bugprone.cpp)
set_property(TARGET tidy-bugprone PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-bugprone lionss pthread)

add_executable(concepts-check src/concepts-check.cpp)
set_property(TARGET concepts-check PROPERTY CXX_STANDARD 11)
target_link_libraries(concepts-check lionss pthread)

add_executable(cmake-config-export src/cmake-config-export.cpp)
set_property(TARGET cmake-config-export PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-config-export lionss pthread)

add_executable(memory-sanitizer src/memory-sanitizer.cpp)
set_property(TARGET memory-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-sanitizer lionss pthread)

add_executable(portage-ebuild src/portage-ebuild.cpp)
set_property(TARGET portage-ebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(portage-ebuild lionss pthread)

add_executable(strip-check src/strip-check.cpp)
set_property(TARGET strip-check PROPERTY CXX_STANDARD 11)
target_link_libraries(strip-check lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(autosar-check src/autosar-check.cpp)
set_property(TARGET autosar-check PROPERTY CXX_STANDARD 11)
target_link_libraries(autosar-check lionss pthread)

add_executable(seed-corpus src/seed-corpus.cpp)
set_property(TARGET seed-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(seed-corpus lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(leak-sanitizer src/leak-sanitizer.cpp)
set_property(TARGET leak-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(leak-sanitizer lionss pthread)

add_executable(edge-case-tests src/edge-case-tests.cpp)
set_property(TARGET edge-case-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(edge-case-tests lionss pthread)

add_executable(pin-dependencies src/pin-dependencies.cpp)
set_property(TARGET pin-dependencies PROPERTY CXX_STANDARD 11)
target_link_libraries(pin-dependencies lionss pthread)

add_executable(callgrind-profile src/callgrind-profile.cpp)
set_property(TARGET callgrind-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(callgrind-profile lionss pthread)

add_executable(msan src/msan.cpp)
set_property(TARGET msan PROPERTY CXX_STANDARD 11)
target_link_libraries(msan lionss pthread)

add_executable(spack-build src/spack-build.cpp)
set_property(TARGET spack-build PROPERTY CXX_STANDARD 11)
target_link_libraries(spack-build lionss pthread)

add_executable(concurrency-tests src/concurrency-tests.cpp)
set_property(TARGET concurrency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(concurrency-tests lionss pthread)

add_executable(whitespace-check src/whitespace-check.cpp)
set_property(TARGET whitespace-check PROPERTY CXX_STANDARD 11)
target_link_libraries(whitespace-check lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(package-nsis src/package-nsis.cpp)
set_property(TARGET package-nsis PROPERTY CXX_STANDARD 11)
target_link_libraries(package-nsis lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

